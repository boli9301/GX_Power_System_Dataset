The file recods the codes and data of visualization.
'Data/' file correspongds to 'Visualization/'.
Notably, the filepaths in codes need to be modified by users.