import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# Load the data from Sheet4
file_path = "fig4data.xlsx"
sheet_name = "Sheet1"
df = pd.read_excel(file_path, sheet_name=sheet_name, header=None)

# Define column indices
load_col = 0 
coal_col = 2 

# Identify unit types and their data ranges
unit_sections = {
    "Subcritical 300MW": (1, 21),
    "Supercritical 300MW": (22, 44),
    "Subcritical 600MW": (45, 64),
    "Supercritical 600MW": (65, 84),
    "Ultra-supercritical 600MW": (85, 109),
    "Ultra-supercritical 1000MW": (110, 130)
}

# Set font
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 22

# Create figure
plt.figure(figsize=(12, 8))

# Colors for each unit
colors = {
    "Subcritical 300MW": "blue",
    "Supercritical 300MW": "red",
    "Subcritical 600MW": "green",
    "Supercritical 600MW": "orange",
    "Ultra-supercritical 600MW": "blueviolet",
    "Ultra-supercritical 1000MW": "brown"
}

# Plot each unit with full curve and two selected points
for unit, (start, end) in unit_sections.items():
    # Get all data points for this unit
    load_values = df.iloc[start:end, load_col].astype(float)
    coal_values = df.iloc[start:end, coal_col].astype(float)
    
    # Plot the full curve
    plt.plot(load_values, coal_values, label=unit, color=colors[unit], linewidth=2)
    
    # Select two points: second and second last
    if len(load_values) >= 4:  # Ensure we have at least 4 points to get second and second last
        second_load = load_values.iloc[1]
        second_coal = coal_values.iloc[1]
        second_last_load = load_values.iloc[-2]
        second_last_coal = coal_values.iloc[-2]
        
        # Plot the selected points with markers
        plt.scatter([second_load, second_last_load], [second_coal, second_last_coal], 
                   color=colors[unit], s=80, zorder=5)  # s is marker size, zorder ensures points are on top

# Labels and title
plt.xlabel("Load (MW)")
plt.ylabel("Standard Coal Consumption Rate (g/kWh)")
plt.legend()

# Show plot
plt.tight_layout()
plt.show()