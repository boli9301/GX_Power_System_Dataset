The file records the visualization codes for Fig7-Fig9 in our paper.
To reduce complexity, the codes of Fig6 are presented in '.m' format.
'CHINA' file includes the map of Guangxi, which is shown in state level.