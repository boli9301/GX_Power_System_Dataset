data = xlsread('fig6data.xlsx');
solar = data(:,1);
wind = data(:,2);
figure;
plot(solar,'k');
hold on;
plot(wind,'g');