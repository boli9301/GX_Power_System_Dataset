import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime, timedelta

# Times New Roman
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 28


df = pd.read_excel('fig10data.xlsx', sheet_name='Sheet1')
df = df/1000

start_date = datetime(2023, 1, 1)  
dates = [start_date + timedelta(hours=i) for i in range(len(df))]

df['datetime'] = dates

monthly_15th = df[df['datetime'].dt.day == 15]

x_positions = range(len(monthly_15th))

colors = [
    'black',      # coal
    'pink',       # gas
    'brown',      # biomass
    'deepskyblue',    # hydro
    'red',        # nuclear
    'orange',     # pv
    'limegreen',  # wind
    'gray',       # line
    'blue',       # phs
    'purple'      # bs
]

plt.figure(figsize=(16, 9))

columns_to_plot = ['Coal', 'Gas', 'Biomass', 'Hydropower', 'Nuclear', 'Solar PV', 'Wind', 'Interprovincial Power', 'PHS', 'Battery Storage']
plt.stackplot(x_positions, 
              [monthly_15th[col] for col in columns_to_plot],
              labels=columns_to_plot,
              colors=colors,
              alpha=0.8)

plt.plot(x_positions, monthly_15th['Load'], color='black', linewidth=1, label='Load', marker='o', markersize = 3)

plt.ylabel('Power Output (GW) and Load (GWh)', fontname='Times New Roman')

month_abbr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
              'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

xxx = [12,36,60,84,108,132,156,180,204,228,252,276]
plt.xticks(xxx, month_abbr[:len(monthly_15th)])

plt.legend(bbox_to_anchor=(0.5, 1.02), loc='lower center', 
           ncol=4, frameon=True, fancybox=True, shadow=True)

plt.xlim(-0.5, len(monthly_15th)-0.5)
plt.ylim(0, max(monthly_15th['Load']) * 1.1)
plt.tight_layout()
plt.show()