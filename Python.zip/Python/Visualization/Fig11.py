import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

df = pd.read_excel('fig11data.xlsx', sheet_name='Sheet1')

plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['mathtext.fontset'] = 'stix'

energy_types = ['Coal', 'Gas', 'Biomass', 'Hydropower', 'Nuclear', 'Solar PV', 'Wind']
energy_colors = {
    'Coal': 'black',
    'Gas': 'pink',
    'Biomass': 'brown',
    'Hydropower': 'deepskyblue',
    'Nuclear': 'red',
    'Solar PV': 'orange',
    'Wind': 'limegreen'
}

df_converted = df.copy()
for col in df.columns[1:]:
    df_converted[col] = df[col] / 1000000

cities = df_converted['bus'].tolist()

fig, ax = plt.subplots(figsize=(16, 12)) 

x_pos = np.arange(len(cities))
width = 0.35

bottom = np.zeros(len(cities))
for energy_type in energy_types:
    if energy_type in df_converted.columns:
        values = df_converted[energy_type].values
        ax.bar(x_pos - width/2, values, width, bottom=bottom, 
               label=energy_type, color=energy_colors[energy_type], 
               alpha=0.8, edgecolor='white', linewidth=0.5)
        bottom += values

load_values = df_converted['Load'].values
ax.bar(x_pos + width/2, load_values, width, alpha=0.7, color='gray', 
       label='Load', edgecolor='black', linewidth=1)

ax.set_ylabel('Power Generation and Load (TWh)', fontsize=36, fontname='Times New Roman')
ax.tick_params(axis='y', labelsize=36)
for label in ax.get_yticklabels():
    label.set_fontname('Times New Roman')
    
ax.set_xticks(x_pos)
ax.set_xticklabels(cities, rotation=5, ha='center', fontsize=28)

for label in ax.get_xticklabels():
    label.set_fontname('Times New Roman')

handles, labels = ax.get_legend_handles_labels()

legend = fig.legend(handles, labels, 
                   loc='upper center', 
                   bbox_to_anchor=(0.41, 0.9), 
                   ncol=4, 
                   fontsize=31, 
                   frameon=True, 
                   fancybox=True, 
                   shadow=True)

for text in legend.get_texts():
    text.set_fontname('Times New Roman')

plt.tight_layout(rect=[0, 0, 1, 0.92])
plt.show()