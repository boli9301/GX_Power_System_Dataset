import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D 
from shapely.geometry import Point

plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 22

# Excel data
df = pd.read_excel('fig3data.xlsx', sheet_name='Sheet1')

# Guangxi map
guangxi = gpd.read_file('CHINA/gx/gx.shp')

# GeoDataFrame
geometry = [Point(xy) for xy in zip(df['Longitude'], df['Latitude'])]
gdf = gpd.GeoDataFrame(df, geometry=geometry, crs=guangxi.crs)

points_in_guangxi = gpd.sjoin(gdf, guangxi, how='inner', predicate='within')

# picture set
fig, ax = plt.subplots(figsize=(18, 9))
ax.set_facecolor('w') 

# Guangxi map
guangxi.plot(ax=ax, edgecolor='k', linewidth=1.5, facecolor='w')
color_map = {
    'Coal': 'dimgrey',
    'Gas': 'm',
    'Biomass': 'brown',
    'Hydropower': 'deepskyblue',
    'Nuclear': 'red',
    'Solar PV': 'orange',
    'Wind': 'limegreen',
    'PHS': 'royalblue',
    'Battery Storage': 'hotpink'
}

# point size
min_size = 10
max_size = 150

for gen_type, color in color_map.items():
    type_data = points_in_guangxi[points_in_guangxi['Gen_type'] == gen_type]
    
    if len(type_data) > 0:
        sizes = np.clip(type_data['Capacity'] / type_data['Capacity'].max() * max_size, min_size, max_size)
        
        ax.scatter(
            type_data['Longitude'],
            type_data['Latitude'],
            s=sizes,
            c=color,
            alpha=0.6, 
            edgecolors='none',
        )

# x,y set
ax.set_xlim(guangxi.total_bounds[0] - 1.5, guangxi.total_bounds[2] + 0.5)
ax.set_ylim(guangxi.total_bounds[1] - 0.5, guangxi.total_bounds[3] + 0.5)
legend_size = 80  

legend_elements = []
for gen_type, color in color_map.items():
    legend_elements.append(
        plt.Line2D([0], [0], 
                  marker='o', 
                  color='w', 
                  markerfacecolor=color,
                  markersize=np.sqrt(legend_size*2),
                  label=gen_type,
                  alpha=0.6)
    )

points_data = {
    'BS': (106.619, 23.9022),
    'BH': (109.12, 21.4813),
    'CZ': (107.364, 22.3784),
    'FCG': (108.354, 21.6867),
    'GG': (109.594, 23.1115),
    'GL': (110.179, 25.2345),
    'HC': (108.085, 24.6929),
    'HZ': (111.566, 24.4036),
    'LB': (109.216, 23.75),
    'LZ': (109.415, 24.325),
    'NN': (108.366, 22.819),
    'QZ': (108.654, 21.9797),
    'WZ': (111.279, 23.4771),
    'YL': (110.18, 22.654),
}

offset_data = {
    'BS': (0, 0),  
    'BH': (0.2, 0.1), 
    'CZ': (0, 0),  
    'FCG': (-0.2, 0.1), 
    'GG': (0, 0),  
    'GL': (0, 0),    
    'HC': (0, 0),       
    'HZ': (0, 0),     
    'LB': (0, 0),     
    'LZ': (0, 0),     
    'NN': (0, 0),    
    'QZ': (0, 0),   
    'WZ': (0, 0),    
    'YL': (0, 0),     
}

# bus name
for city, (lon, lat) in points_data.items():
    dx, dy = offset_data.get(city, (0.2, 0.1)) 
    
    ax.annotate(city, 
                xy=(lon, lat), 
                xytext=(lon + dx, lat + dy),
                fontsize=20,
                fontfamily='Times New Roman',
                color='black',
                ha='center', 
                va='center', 
                bbox=dict(boxstyle='round,pad=0.2', 
                         facecolor='white', 
                         edgecolor='k', 
                         alpha=0.3,
                         linewidth=0.8),
                zorder=10)

# legend
ax.legend(handles=legend_elements, loc='lower left')
ax.set_xlabel('Longitude')
ax.set_ylabel('Latitude')

plt.tight_layout()
plt.show()