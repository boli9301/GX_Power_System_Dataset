import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import FancyArrowPatch
from matplotlib.lines import Line2D

# Times New Roman
plt.rcParams['font.family'] = 'Times New Roman'

guangxi = gpd.read_file('CHINA/gx/gx.shp')
df_points = pd.read_excel('fig7-fig9data.xlsx', sheet_name='Sheet1')
df_flow = pd.read_excel('fig7-fig9data.xlsx', sheet_name='Sheet2')

df_first_14 = df_points.head(14).copy()

geometry = gpd.points_from_xy(df_first_14['lon'], df_first_14['lat'])
gdf_points = gpd.GeoDataFrame(df_first_14, geometry=geometry, crs='EPSG:4326')

guangxi_with_voltage = gpd.sjoin(guangxi, gdf_points, how='left', predicate='intersects')

fig, ax = plt.subplots(1, 1, figsize=(12, 8))

colors = ['#9ECAE1', '#C6DBEF', '#EFF3FF', '#FFFFFF', '#FEE5D9']
cmap = LinearSegmentedColormap.from_list('blue_red_smooth', colors, N=256)

vmin = df_first_14['load'].min()
vmax = df_first_14['load'].max()

guangxi_with_voltage.plot(column='load', 
                         ax=ax, 
                         cmap=cmap,
                         vmin=vmin,
                         vmax=vmax,
                         legend=True,
                         missing_kwds={'color': 'lightgray', 'edgecolor': 'black', 'hatch': '//'},
                         edgecolor='black',
                         linewidth=0.4,
                         legend_kwds={
                             'shrink': 0.8,
                             'aspect': 15,
                             'pad': 0
                         })

cbar = ax.get_figure().get_axes()[1]
cbar.set_ylabel('Voltage (p.u.)', fontsize=22, fontfamily='Times New Roman')
cbar.tick_params(labelsize=20)

node_coords = {}
for _, row in df_points.iterrows():
    node_coords[row['bus']] = (row['lon'], row['lat'])

voltage_colors = {
    500: 'coral', 
    800: 'royalblue', 
    220: 'c'  
}

for _, line in df_flow.iterrows():
    f_bus = line['f']
    t_bus = line['t']
    p = line['p']
    v_level = line['v']
    cate = line['cate']

    if f_bus in node_coords and t_bus in node_coords:
        start_node = f_bus
        end_node = t_bus
        
        if p < 0:
            start_node, end_node = end_node, start_node
            p = abs(p)
        
        start_coord = node_coords[start_node]
        end_coord = node_coords[end_node]
        
        color = voltage_colors.get(v_level, '#666666')
        
        dx = end_coord[0] - start_coord[0]
        dy = end_coord[1] - start_coord[1]
        line_length = np.sqrt(dx**2 + dy**2)
        
        max_p = df_flow['p'].abs().max()
        linewidth = 1.0 + (abs(p) / max_p) * 4
        
        linestyle = 'dashed' if cate == 'DC' else 'solid'
        
        ax.plot([start_coord[0], end_coord[0]], 
                [start_coord[1], end_coord[1]], 
                color=color, 
                linewidth=linewidth, 
                alpha=0.8,
                linestyle=linestyle, 
                solid_capstyle='round')
        
        num_arrows = max(2, int(line_length * 2.5))
        arrow_size = linewidth * 8 
        
        for i in range(1, num_arrows):
            t = i / num_arrows
            arrow_x = start_coord[0] + t * dx
            arrow_y = start_coord[1] + t * dy
            
            arrow = FancyArrowPatch(
                (arrow_x - dx/(num_arrows*4), arrow_y - dy/(num_arrows*4)),
                (arrow_x + dx/(num_arrows*4), arrow_y + dy/(num_arrows*4)),
                arrowstyle='->',
                mutation_scale=arrow_size,
                color=color,
                linewidth=linewidth/2,
                alpha=0.9,
                zorder=5
            )
            ax.add_patch(arrow)

points_data = {
    'BS': (106.619, 23.9022),
    'BH': (109.12, 21.4813),
    'CZ': (107.364, 22.3784),
    'FCG': (108.354, 21.6867),
    'GG': (109.594, 23.1115),
    'GL': (110.179, 25.2345),
    'HC': (108.085, 24.6929),
    'HZ': (111.566, 24.4036),
    'LB': (109.216, 23.75),
    'LZ': (109.415, 24.325),
    'NN': (108.366, 22.819),
    'QZ': (108.654, 21.9797),
    'WZ': (111.279, 23.4771),
    'YL': (110.18, 22.654),
    'Longtan': (107.04, 25.03),
    'Yantan': (107.51, 24.04),
    'Funing': (105.53, 23.54),
    'Tianshengqiao': (105.11, 24.95),
    'Guizhou': (107.534, 25.8),
    'Liping': (109.105, 26.21),
    'Kunbei': (105.365, 25.357),
    'Jinguan': (104.67, 25.39),
    'Nuclear': (108.5571,21.6697)
}

offset_data = {
    'BS': (0.25, -0.4),  
    'BH': (0.4, -0.1),  
    'CZ': (0.4, 0.1),  
    'FCG': (-0.6, 0.1), 
    'GG': (-0.3, -0.2),   
    'GL': (-0.4, 0.1),      
    'HC': (-0.3, -0.2),  
    'HZ': (0.4, -0.1),  
    'LB': (0.4, 0.1),   
    'LZ': (0.45, 0.1), 
    'NN': (0.4, 0.1),  
    'QZ': (0.4, 0.25),    
    'WZ': (-0.4, 0.1),     
    'YL': (0.4, 0.1),    
    'Longtan': (-0.4, 0.35), 
    'Yantan': (0.55, -0.1),  
    'Funing': (-0.65, 0.1),
    'Tianshengqiao': (-0.5, -0.3),
    'Guizhou': (-0.3, 0.25),
    'Liping': (-0.5, 0),
    'Kunbei': (0, 0.3),
    'Jinguan': (-0.6, 0),
    'Nuclear': (0, -0.4)
}

for city, (lon, lat) in points_data.items():
    dx, dy = offset_data.get(city, (0.2, 0.1))
    ax.annotate(city, 
                xy=(lon, lat), 
                xytext=(lon + dx, lat + dy),
                fontsize=20,
                fontfamily='Times New Roman',
                color='black',
                ha='center',  
                va='center', 
                bbox=dict(boxstyle='round,pad=0.2', 
                         facecolor='white', 
                         edgecolor='k', 
                         alpha=0.8,
                         linewidth=0.8),
                arrowprops=dict(arrowstyle='->',
                               color='k',
                               linewidth=1,
                               alpha=0.7,
                               connectionstyle="arc3,rad=0.1"),
                zorder=10)

legend_elements = [
    # DC  
    Line2D([0], [0], color=voltage_colors[800], lw=2, linestyle='dashed', label='±800 kV DC'),
    Line2D([0], [0], color=voltage_colors[500], lw=2, linestyle='dashed', label='±500 kV DC'),
    # AC
    Line2D([0], [0], color=voltage_colors[500], lw=2, linestyle='solid', label='500 kV AC'),
    Line2D([0], [0], color=voltage_colors[220], lw=2, linestyle='solid', label='220 kV AC'),
]

ax.legend(handles=legend_elements, 
          loc='lower left', 
          fontsize=20)

ax.set_axis_off()

ax.set_xlim([104, 112.5])
ax.set_ylim([21, 27])

plt.tight_layout()
plt.show()

print("Voltage statistics for first 14 points:")
print(f"Min voltage: {vmin:.4f}")
print(f"Max voltage: {vmax:.4f}")
print(f"Average voltage: {df_first_14['load'].mean():.4f}")

print("\nPower flow information:")
print(f"Number of transmission lines: {len(df_flow)}")
print(f"Max active power: {df_flow['p'].abs().max():.2f} MW")
print(f"Min active power: {df_flow['p'].abs().min():.2f} MW")
print(f"Voltage levels: {df_flow['v'].unique()}")