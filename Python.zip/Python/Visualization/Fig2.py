import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Times New Roman
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 32

df_plants = pd.read_excel('fig2data.xlsx', sheet_name='Sheet1')
df_load = pd.read_excel('fig2data.xlsx', sheet_name='Sheet2')

df_load_long = df_load.melt(var_name='state', value_name='load')
df_load_long['load_MW'] = df_load_long['load'] / 1000000

energy_colors = {
    'Coal': 'k',
    'Gas': 'pink',
    'Biomass': 'brown',
    'Hydropower': 'deepskyblue',
    'Nuclear': 'red',
    'Solar PV': 'orange',
    'Wind': 'limegreen',
    'PHS': 'royalblue',
    'Battety Storage': 'm'
}

capacity_by_state_energy = df_plants.groupby(['state', 'energy_type'])['Pmax'].sum().unstack(fill_value=0)
for energy_type in energy_colors.keys():
    if energy_type not in capacity_by_state_energy.columns:
        capacity_by_state_energy[energy_type] = 0

capacity_by_state_energy = capacity_by_state_energy[list(energy_colors.keys())]

states_ordered = capacity_by_state_energy.index.tolist()
df_load_long = df_load_long.set_index('state').reindex(states_ordered).reset_index()

fig, ax1 = plt.subplots(figsize=(16, 12))
ax2 = ax1.twinx() 

x_pos = np.arange(len(states_ordered))
width = 0.35 

bottom = np.zeros(len(states_ordered))
for i, energy_type in enumerate(capacity_by_state_energy.columns):
    if energy_type in energy_colors:
        values = capacity_by_state_energy[energy_type].values
        ax1.bar(x_pos - width/2, values, width, bottom=bottom, 
                label=energy_type, color=energy_colors[energy_type], 
                alpha=0.8, edgecolor='white', linewidth=0.5)
        bottom += values

load_values = df_load_long['load_MW'].values
ax2.bar(x_pos + width/2, load_values, width, alpha=0.7, color='gray', 
        label='Load', edgecolor='black', linewidth=1)

ax1.set_ylabel('Installed Capacity (MW)', fontsize=34)
ax1.tick_params(axis='y', labelsize=34)
ax1.set_xticks(x_pos)
ax1.set_xticklabels(states_ordered, rotation=25, ha='center', fontsize=34) 

ax2.set_ylabel('Load (TWh)', fontsize=34)
ax2.tick_params(axis='y', labelsize=34) 

handles1, labels1 = ax1.get_legend_handles_labels()
handles2, labels2 = ax2.get_legend_handles_labels()
all_handles = handles1 + handles2
all_labels = labels1 + labels2

fig.legend(all_handles, all_labels, 
           loc='upper center', 
           bbox_to_anchor=(0.5, 1), 
           ncol=5,
           fontsize=30, 
           frameon=True, 
           fancybox=True, 
           shadow=True)

plt.tight_layout(rect=[0, 0, 1, 0.88])
plt.show()

print("Capacity and Load Summary by State (MW):")
print("=" * 80)
for state in states_ordered:
    total_capacity = capacity_by_state_energy.loc[state].sum()
    load_value = df_load_long[df_load_long['state'] == state]['load_MW'].values[0]
    capacity_load_ratio = total_capacity / load_value if load_value > 0 else float('inf')
    print(f"{state:15} | Capacity: {total_capacity:8.1f} MW | Load: {load_value:8.1f} MW | Ratio: {capacity_load_ratio:5.2f}")

print("\nTotal Capacity by Energy Type (MW):")
print("=" * 50)
for energy_type in energy_colors.keys():
    total = capacity_by_state_energy[energy_type].sum()
    print(f"{energy_type:20} : {total:10.1f} MW")