import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

# Set English font (Times New Roman)
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 24

# Read Excel file
file_path = 'fig5data.xlsx'

# Read first sheet - connection relationships
df_connections = pd.read_excel(file_path, sheet_name='Sheet1')

# Read second sheet - coordinate information
df_coords = pd.read_excel(file_path, sheet_name='Sheet2')

# Create coordinate dictionary and type dictionary
coord_dict = {}
point_types = {}

# Process coordinate data
for idx, row in df_coords.iterrows():
    point_name = row['name']
    lat = row['lat']  # Latitude
    lon = row['lon']  # Longitude
    point_type = row['type']  # Type
    
    coord_dict[point_name] = (lon, lat)
    point_types[point_name] = point_type

# Read Guangxi map
guangxi = gpd.read_file('CHINA/gx/gx.shp')

# Create figure
fig, ax = plt.subplots(1, 1, figsize=(12, 8))

# Plot Guangxi map
guangxi.plot(ax=ax, color='white', edgecolor='k', alpha=1)

# Get total number of connections
total_connections = len(df_connections)

# Draw connection lines
for idx, row in df_connections.iterrows():
    point_a = row['F']
    point_b = row['T']
    voltage = row['V']
    
    if point_a in coord_dict and point_b in coord_dict:
        x1, y1 = coord_dict[point_a]
        x2, y2 = coord_dict[point_b]
        
        # Check if this is one of the last two lines (DC lines)
        is_dc_line = (idx >= total_connections - 2)
        
        # Select color, line width and style based on voltage level and line type
        if voltage == 220:
            color = 'red'
            linewidth = 1.5
            alpha = 0.7
            linestyle = '-'  # Solid line for AC
            label_ac = '220kV AC'
            label_dc = None
        elif voltage == 500:
            color = 'purple'
            linewidth = 2.0
            alpha = 0.8
            if is_dc_line:
                linestyle = '--'  # Dashed line for DC
                label_dc = '500kV DC'
                label_ac = None
            else:
                linestyle = '-'  # Solid line for AC
                label_ac = '500kV AC'
                label_dc = None
        elif voltage == 800:
            color = 'blue'
            linewidth = 2.5
            alpha = 0.9
            if is_dc_line:
                linestyle = '--'  # Dashed line for DC
                label_dc = '800kV DC'
                label_ac = None
            else:
                linestyle = '-'  # Solid line for AC
                label_ac = '800kV AC'
                label_dc = None
        else:
            color = 'gray'
            linewidth = 1
            alpha = 0.6
            linestyle = '-'
            label_ac = None
            label_dc = None
        
        # Draw connection line
        ax.plot([x1, x2], [y1, y2], color=color, linewidth=linewidth, alpha=alpha, 
                linestyle=linestyle)

# Draw points - different colors and sizes based on type
for point_name, (lon, lat) in coord_dict.items():
    point_type = point_types.get(point_name, 'Other')
    
    # Select color, marker and size based on point type
    if point_type == 'sub':
        color = 'red'
        marker = 'D'
        size = 120
        edgecolor = 'darkred'
        zorder = 5
    elif point_type == 'con':
        color = 'blue'
        marker = 's'  # Square marker
        size = 120
        edgecolor = 'darkblue'
        zorder = 6
    elif point_type == 'load':
        color = 'black'
        marker = 'o'  # Triangle marker
        size = 120
        edgecolor = 'gray'
        zorder = 4
    elif point_type == 'generator':
        color = 'green'
        marker = 'o'  # Diamond marker
        size = 120
        edgecolor = 'darkgreen'
        zorder = 7
    else:
        color = 'orange'
        marker = 'o'
        size = 50
        edgecolor = 'darkorange'
        zorder = 3
    
    # Draw point (no text labels as requested)
    ax.scatter(lon, lat, c=color, marker=marker, s=size, 
               edgecolors=edgecolor, linewidth=1.5, zorder=zorder, alpha=0.9)

# Set graph properties
#ax.set_title('Guangxi Power Grid Topology', fontsize=18, fontweight='bold', pad=20)
ax.set_xlabel('Longitude', fontsize=24)
ax.set_ylabel('Latitude', fontsize=24)

# Create legend with AC and DC lines
legend_elements = [
    # Voltage level legend - AC lines (solid)
    plt.Line2D([0], [0], color='red', linewidth=2, linestyle='-', label='220kV AC'),
    plt.Line2D([0], [0], color='purple', linewidth=2, linestyle='-', label='500kV AC'),
    # Voltage level legend - DC lines (dashed)
    plt.Line2D([0], [0], color='purple', linewidth=2, linestyle='--', label='±500kV DC'),
    plt.Line2D([0], [0], color='blue', linewidth=2.5, linestyle='--', label='±800kV DC'),
    # Point type legend
    plt.Line2D([0], [0], marker='D', color='w', markerfacecolor='red', 
               markeredgecolor='darkred', markersize=10, label='Substation'),
    plt.Line2D([0], [0], marker='s', color='w', markerfacecolor='blue', 
               markeredgecolor='darkblue', markersize=10, label='Converter Station'),
    plt.Line2D([0], [0], marker='o', color='w', markerfacecolor='black', 
               markeredgecolor='gray', markersize=10, label='Load Bus'),
    plt.Line2D([0], [0], marker='o', color='w', markerfacecolor='green', 
               markeredgecolor='darkgreen', markersize=10, label='Generation Unit')
]


points_data = {
    'BS': (106.619, 23.9022),
    'BH': (109.12, 21.4813),
    'CZ': (107.364, 22.3784),
    'FCG': (108.354, 21.6867),
    'GG': (109.594, 23.1115),
    'GL': (110.179, 25.2345),
    'HC': (108.085, 24.6929),
    'HZ': (111.566, 24.4036),
    'LB': (109.216, 23.75),
    'LZ': (109.415, 24.325),
    'NN': (108.366, 22.819),
    'QZ': (108.654, 21.9797),
    'WZ': (111.279, 23.4771),
    'YL': (110.18, 22.654),
    'Longtan': (107.04, 25.03),
    'Yantan': (107.51, 24.04),
    'Funing': (105.53, 23.54),
    'Tianshengqiao': (105.11, 24.95),
    'Guizhou': (107.534, 25.8),
    'Liping': (109.105, 26.21),
    'Kunbei': (105.365, 25.357),
    'Jinguan': (104.67, 25.39),
    'Nuclear': (108.557, 21.67)
}


offset_data = {
    'BS': (0.25, -0.4),       
    'BH': (0.4, -0.1),       
    'CZ': (0.4, 0.1),     
    'FCG': (-0.6, 0.1), 
    'GG': (-0.3, -0.2),  
    'GL': (-0.4, 0.1),   
    'HC': (-0.3, -0.2),    
    'HZ': (0.4, -0.1),    
    'LB': (0.4, 0.1),     
    'LZ': (0.45, 0.05),    
    'NN': (0.4, 0.1),    
    'QZ': (0.4, 0.3),   
    'WZ': (-0.4, 0.1),  
    'YL': (0.4, 0.1),   
    'Longtan': (-0.4, 0.35), 
    'Yantan': (0.55, -0.1),
    'Funing': (-0.65, 0.1),
    'Tianshengqiao': (-0.5, -0.3),
    'Guizhou': (-0.3, 0.25),
    'Liping': (-0.5, 0),
    'Kunbei': (0, 0.3),
    'Jinguan': (-0.6, 0),
    'Nuclear': (0, 0)
}

for city, (lon, lat) in points_data.items():
    dx, dy = offset_data.get(city, (0.2, 0.1)) 
    
    ax.annotate(city, 
                xy=(lon, lat), 
                xytext=(lon + dx, lat + dy),
                fontsize=20,
                fontfamily='Times New Roman',
                color='black',
                ha='center',  
                va='center',  
                bbox=dict(boxstyle='round,pad=0.2', 
                         facecolor='white', 
                         edgecolor='k', 
                         alpha=0.8,
                         linewidth=0.8),
                arrowprops=dict(arrowstyle='->',
                               color='k',
                               linewidth=1,
                               alpha=0.7,
                               connectionstyle="arc3,rad=0.1"),
                zorder=10)

ax.legend(handles=legend_elements, loc='lower left', framealpha=0.95, 
          fontsize=22)

# Set coordinate range to fit Guangxi geographical location
ax.set_xlim(103, 112.5)
ax.set_ylim(20.5, 26.5)
#plt.axis('off')
# Adjust layout
plt.tight_layout()

# Display graph
plt.show()