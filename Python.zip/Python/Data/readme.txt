The file records the visualization data corresponding to Fig2-Fig11 in our paper.
Notably, the visualizations of Fig7-Fig9 are needed to adjust different scenarios by users.
Data are sourced from test system data, AC power flow analysis, and economic dispatch.